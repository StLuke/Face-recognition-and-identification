-Preklad:
  qmake pov.pro
  make
-Stazeni datasetu z www.stud.fit.vutbr.cz/~xhutak00/pov/pics2.zip a www.stud.fit.vutbr.cz/~xhutak00/pov/pics.zip a www.stud.fit.vutbr.cz/~xhutak00/pov/test.zip
-Nakopirovani datasetu do predem pripravenych slozek "pics" a "pics2" a "test"
-Spusteni
  ./pov